# KodeLibrary (Web)

## Introduction

KodeLibrary is the manager program books on shcool and librarys. It's open source

<img src="images/kode.png" />

## Setup

Follow the [KodeLibrary][codelab] to set up this program.

## License

© Google, 2018. Licensed under an [Apache-2](./LICENSE) license.


[codelab]: https://kodelang.dev

