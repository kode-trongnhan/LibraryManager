#!/bin/bash
ECHO OFF
cd "223-electron-screen-recorder-master"
npm install 
npm start