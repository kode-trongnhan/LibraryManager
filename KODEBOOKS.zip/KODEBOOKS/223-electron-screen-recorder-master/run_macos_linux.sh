#!/bin/bash
npm install 
npm start